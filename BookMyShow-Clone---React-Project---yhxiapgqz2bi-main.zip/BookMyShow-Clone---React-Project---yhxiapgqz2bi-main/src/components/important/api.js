export const apiUrl = {
    key : "3f8245cec6ed13b0d9466b7a244dfe51",
    base : "https://api.themoviedb.org/3/",
    getGenres : "genre/movie/list",
    nowPlaying : "movie/now_playing",
    language : "language=en-US",
    imageBase : "https://image.tmdb.org/t/p/w500"
}
