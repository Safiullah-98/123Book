import React from 'react'
import '../styles/App.css'

export function Validation() {
  return (
    <div className='validIt'><p>Please login before Booking Ticket</p></div>
  )
}
